const API_KEY = "61a70403a51fa8f982afd1596057d85c";
const BASE_URL = "https://api.themoviedb.org/3";
const IMAGE_BASE_URL = "https://image.tmdb.org/t/p/w500";
const DUMMY_BASE_URL = "https://dummyimage.com";
const LANGUAGE = "ko";

export { API_KEY, BASE_URL, IMAGE_BASE_URL, LANGUAGE, DUMMY_BASE_URL };
